# Changelog

## [1.0.12.0] U41-496912-S
- updated

## [1.0.11.0]
- made building placeable underwater

## [1.0.10.0] U38-487396-S

### Fixed
- fixed one incompatability with "Laser Turrets"; SweepThoseEggs must have a later load order (bottom of mod list)
- fixed mod incompatibility with mods that change baggable tags

## [1.0.9.0] EX1 S14-471883-S

### Fixed
- fixed missing building initialisation
- set vanilla flag, so it can load without DLC

## [1.0.8.0] EX1 S13-469473

### Changed
- updated to Harmony 2.0

## [1.0.7.0] EX1 S6-449549

### Changed
- only works in rooms of 200 tiles or fewer

### Fixed
- fixed Pacu not being able to be delivered
- fixed stored eggs being counted against critter limit
- fixed eggs outside of stable to be marked, if moved by conveyor belts

### Removed
- removed redundant wangle critter option (just use a Critter Drop-Off)

## [1.0.6.0] EX1 S6-448916

### Fixed
- updated for DLC1

## [1.0.5.0] EX1 S6-448916

### Changed
- fetch jobs copy the buildings priority

### Fixed
- updated for DLC1

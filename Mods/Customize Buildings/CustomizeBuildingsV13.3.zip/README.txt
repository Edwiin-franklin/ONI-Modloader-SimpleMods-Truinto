README v12

Settings here:
%userprofile%\documents\Klei\OxygenNotIncluded\mods\Steam\1818138009\CustomizeBuildingsState.json

or here if path above does not exist; fill <Steam> with your actual Steam folder!
Steam\SteamApps\common\OxygenNotIncluded\Mods\EasierBuildings\Config\CustomizeBuildingsState.json

If CustomizeBuildingsState.json is corrupted or otherwise does not work, delete it and restart the game. A new clean file will be generated.

KleiSettings.json contains the settings necessary to essentially turn off all features. You can work from there and re-enable certain settings as you like.
Otherwise the settings are self explanatory.

Special settings:
  "ReservoirNoGround": reservoirs can be placed in the air
  "NoDupeValves": valves are set instantly without dupe interaction
  "NoDupeOilRefinery": the oil refinery works without a dupe
  "ReservoirManualDelivery": dupes may store material in reservoirs (off by default)
        - dupes will deliver selected liquids/gases until the capacity is at the slider amount
        - liquid/gas pipes can still deliver any element and will ignore the slider limit
        - activating, then deactivating an element checkbox drops it on the floor, for easy removal of rogue elements
        - furthermore reservoirs get logic output, outputing green when capacity is over slider amount
  "AirfilterDropsCanisters": on deconstruction, airfilters (as well as all other buildings) drop gas canisters instead of venting stored gases
  
  "ScannerInterferenceRadius": radius looking for heavy machinery and free sky tiles
  "ScannerWorstWarningTime": worst time before a network will detect incoming meteors
  "ScannerBestWarningTime": best time before a network will detect incoming meteors
  "ScannerBestNetworkSize": amount of scanners needed for best warning time

  "NoDupeBuildings": buildings will not require a dupe to run
Following settings are not implemented yet:
    "Automated Compost": false,
    "Ice Fan": false,
    "Shearing Station": false,
    "Grooming Station": false

  "BuildingBaseSettings": can change a list of BuildingDef options of any building (even from other mods)
	- this may be defined with either building ID or ingame name (case sensitive)
	- null will keep the original setting
	- all these settings are optional and can be removed
	PowerConsumption: amount of power needed, some buildings will crash when set to 0 Watts, notably filters/shutoffs
	OverheatTemperature: temperature the building will stop working in Kelvin
	MaterialCategory: if present this must be one or two entries depending if the original building is building with 1 or 2 materials; each entry must be a valid Tag like: Metal, RefinedMetal, Alloy, BuildableRaw, BuildableProcessed, PreciousRock, Farmable, Plastic, Glass, Transparent, BuildingFiber, FlyingCritterEdible, or BuildableAny
	ExhaustKilowattsWhenActive: amount of heat released from the building (will heat building in vacuum instead)
	SelfHeatKilowattsWhenActive: amount of heat directly applied to the building
	WARNING: if kilowattsWhenActive is a negative value and the temperature reaches below 0 Kelvin, the game will crash instantly
	GeneratorWattageRating: amount of power generated from building
	BaseDecor: decor value
	BaseDecorRadius: range of decor value
	LocationRule: use number as seen below as to where the building is allowed to be placed:
		null will keep the original setting
		Anywhere = 0,
		OnFloor = 1,
		OnFloorOverSpace = 2,
		OnCeiling = 3,
		OnWall = 4,
		InCorner = 5,
		Tile = 6,
		NotInTiles = 7,
		Conduit = 8,
		LogicBridge = 9,
		WireBridge = 10,
		HighWattBridgeTile = 11,
		BuildingAttachPoint = 12,
		OnFloorOrBuildingAttachPoint = 13,
		OnFoundationRotatable = 14
	Rotations:
		null will keep the original setting
		Unrotatable = 0,
		R90 = 1,
		R360 = 2,
		FlipH = 3,
		FlipV = 4

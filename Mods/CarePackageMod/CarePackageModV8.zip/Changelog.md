# Changelog

## [1.0.8.0] EX1 S6-449549 CS-449460

### Added
- option to allow reshuffle on printing pod
- option to remove starter restrictions (only 2 traits, some missing dupes)
- option to have always 3 interests
- option for bonus attribute chance
- added UI options for most settings (not possible for package list)
- added button to Printing Pod to change configuration

### Fixed
- fixed non-DLC config being in the wrong folder

## [1.0.7.0] EX1 S6-449549

### Fixed
- updated for DLC

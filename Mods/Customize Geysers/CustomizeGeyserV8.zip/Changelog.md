# Changelog

## [1.0.8.0] EX1 S13-469473

### Changed
- reversed changed config file path and fixed read/write function to use the same path

## [1.0.7.0] EX1 S13-469369

### Changed
- updated to Harmony 2.0

## [1.0.6.0] EX1 S11-464102

### Fixed
- added missing slush_salt_water to the default list

## [1.0.5.0] EX1 S6-448916

### Fixed
- updated for SpacedOut

### Removed
- Highlander mode doesn't work anymore

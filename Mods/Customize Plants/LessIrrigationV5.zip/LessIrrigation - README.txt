README V5

Settings here:
%userprofile%\documents\Klei\OxygenNotIncluded\mods\Steam\1818145851\CustomizeBuildingsState.json

or maybe here (e.g. if you are not playing on Windows):
Steam\SteamApps\common\OxygenNotIncluded\Mods\LessIrrigation\Config\LessIrrigationState.json

The settings work with ingame IDs. These differ from the displayed name!!!!

-- Plant ------- plant id, use in json file! ----
{ "mealwood", "BasicSingleHarvestPlant" },
{ "dusk cap", "MushroomPlant" },
{ "bristle blossom", "PrickleFlower" },
{ "sleet wheat", "ColdWheat" },
{ "waterweed", "SeaLettuce" },
{ "nosh sprout", "BeanPlant" },
{ "pincha pepper", "SpiceVine" },
{ "balm lily", "SwampLily" },
{ "thimble reed", "BasicFabricPlant" },
{ "arbor tree", "ForestTree" },
{ "dasha saltvine", "SaltPlant" },
{ "gas grass", "GasGrass" },
{ "oxyfern", "Oxyfern" },
{ "wheezewort", "ColdBreather" },
{ "bluff briar", "PrickleGrass" },
{ "buddy bud", "BulbPlant" },
{ "mirth leaf", "LeafyPlant" },
{ "jumping joya", "CactusPlant" },
{ "sporechid", "EvilFlower" },

-- Fruit ------- Fruit id, use in json file! ----
{ "meal lice", "BasicPlantFood" },
{ "mushroom", "Mushroom" },
{ "bristle berries", "PrickleFruit" },
{ "sleet wheat grain", "ColdWheatSeed" },
{ "lettuce", "Lettuce" },
{ "nosh bean", "BeanPlantSeed" },
{ "pincha peppernut", "SpiceNut" },
{ "balm lily flower", "SwampLilyFlower" },
{ "reed fiber", "BasicFabric" },
{ "lumber", "WoodLog" },
{ "salt", "Salt" },
{ "gas grass fruit", "GasGrassHarvested" }

Groups:
RemoveIrrigationFromPlants - any matching plant ID will not load the vanilla irrigation, if you want to change existing irrigation then add it here
AddIrrigiation - adds tags to matching plant IDs, liquids will be automatically set to irrigation, everything else to fertilization; consumption is per cycle; note that if you use more than one liquid you cannot use the Hydroponic Farm, other farms work
SetIllumination - any matching plant ID will change the illumination setting; -1 = needs darkness, 0 = works in either, 1 = needs light
SetPlantTempAtmosphere - change temperature and atmosphere; warning high and low are the thresholds a plant grows; max_age is uninteresting
SetPlantCrop - change one crop type to another; if cropId equal the name above it will only change the other options; cropDuration = time in seconds until harvest is ready; numProduced = number of crops ready per harvest

# Changelog

## [1.0.1.1] U41-498381-S
- added access to modifiers

## [1.0.0.0] EX1 S14-471883-S
- first release

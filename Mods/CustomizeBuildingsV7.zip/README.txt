README v6

Settings here:
%userprofile%\documents\Klei\OxygenNotIncluded\mods\Steam\1818138009\CustomizeBuildingsState.json

or here if path above does not exist; fill <Steam> with your actual Steam folder!
Steam\SteamApps\common\OxygenNotIncluded\Mods\EasierBuildings\Config\CustomizeBuildingsState.json

If CustomizeBuildingsState.json is corrupted or otherwise does not work, delete it and restart the game. A new clean file will be generated.

KleiSettings.json contains the settings necessary to essentially turn off all features. You can work from there and re-enable certain settings as you like.
Otherwise the settings are self explanatory.


Special settings:
  "ReservoirNoGround": reservoirs can be placed in the air
  "NoDupeValves": valves and switches are set instantly without dupe interaction
  "NoDupeOilRefinery": the oil refinery works without a dupe

  "ScannerInterferenceRadius": radius looking for heavy machinery and free sky tiles
  "ScannerWorstWarningTime": worst time before a network will detect incoming meteors
  "ScannerBestWarningTime": best time before a network will detect incoming meteors
  "ScannerBestNetworkSize": amount of scanners needed for best warning time


Following settings are not implemented yet:
    "Automated Compost": false,
    "Ice Fan": false,
    "Shearing Station": false,
    "Grooming Station": false